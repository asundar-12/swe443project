package com.example.demo.Listing;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ListingService {

    private final ListingRepository listingRepository;

    @Autowired
    public ListingService(ListingRepository listingRepository) {
        this.listingRepository = listingRepository;
    }

    public List<Listing> getListings(){
       return listingRepository.findAll();
    }

    public Optional<Listing> getListing(int mlsid){
        return listingRepository.findById(mlsid);
    }
}
